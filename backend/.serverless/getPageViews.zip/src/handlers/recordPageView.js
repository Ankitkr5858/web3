"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const dynamoDb = process.env.NODE_ENV === 'test' ? require('../test/setup').mockDynamoDb : new aws_sdk_1.DynamoDB.DocumentClient({
    region: process.env.AWS_REGION
});
const handler = async () => {
    const timestamp = Math.floor(Date.now() / 60000) * 60000; // Round to nearest minute
    const params = {
        TableName: process.env.DYNAMODB_TABLE,
        Key: { timestamp },
        UpdateExpression: 'SET #count = if_not_exists(#count, :zero) + :inc',
        ExpressionAttributeNames: {
            '#count': 'count'
        },
        ExpressionAttributeValues: {
            ':inc': 1,
            ':zero': 0
        },
        ReturnValues: 'NONE'
    };
    try {
        await dynamoDb.update(params).promise();
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ message: 'Page view recorded' })
        };
    }
    catch (error) {
        console.error('Error recording page view:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ error: 'Could not record page view' })
        };
    }
};
exports.handler = handler;
