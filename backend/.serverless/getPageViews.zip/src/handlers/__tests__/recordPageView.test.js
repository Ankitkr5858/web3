"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const recordPageView_1 = require("../recordPageView");
const aws_sdk_1 = require("aws-sdk");
const mockDynamoDb = new aws_sdk_1.DynamoDB.DocumentClient();
describe('recordPageView handler', () => {
    const mockEvent = {
        httpMethod: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    };
    const mockContext = {};
    const mockCallback = jest.fn();
    beforeEach(() => {
        // Reset mock implementation before each test
        mockDynamoDb.update.mockReturnValue({
            promise: jest.fn().mockResolvedValue({})
        });
        mockCallback.mockClear();
    });
    it('should record a page view successfully', async () => {
        const response = await (0, recordPageView_1.handler)(mockEvent, mockContext, mockCallback);
        expect(response.statusCode).toBe(200);
        expect(JSON.parse(response.body)).toEqual({
            message: 'Page view recorded'
        });
        expect(mockDynamoDb.update).toHaveBeenCalled();
    });
    it('should handle errors gracefully', async () => {
        mockDynamoDb.update.mockReturnValue({
            promise: jest.fn().mockRejectedValue(new Error('DynamoDB error'))
        });
        const response = await (0, recordPageView_1.handler)(mockEvent, mockContext, mockCallback);
        expect(response.statusCode).toBe(500);
        expect(JSON.parse(response.body)).toEqual({
            error: 'Could not record page view'
        });
        expect(mockDynamoDb.update).toHaveBeenCalled();
    });
});
