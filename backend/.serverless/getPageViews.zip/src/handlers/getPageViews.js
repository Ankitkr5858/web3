"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_sdk_1 = require("aws-sdk");
const dynamoDb = process.env.NODE_ENV === 'test' ? require('../test/setup').mockDynamoDb : new aws_sdk_1.DynamoDB.DocumentClient({
    region: process.env.AWS_REGION
});
const handler = async () => {
    const now = Date.now();
    const oneHourAgo = now - 3600000;
    const params = {
        TableName: process.env.DYNAMODB_TABLE,
        KeyConditionExpression: '#timestamp >= :oneHourAgo',
        ExpressionAttributeNames: {
            '#timestamp': 'timestamp'
        },
        ExpressionAttributeValues: {
            ':oneHourAgo': oneHourAgo
        }
    };
    try {
        const result = await dynamoDb.query(params).promise();
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify(result.Items)
        };
    }
    catch (error) {
        console.error('Error fetching page views:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true,
            },
            body: JSON.stringify({ error: 'Could not fetch page views' })
        };
    }
};
exports.handler = handler;
