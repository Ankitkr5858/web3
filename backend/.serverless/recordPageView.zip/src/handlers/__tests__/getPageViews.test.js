"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const getPageViews_1 = require("../getPageViews");
const aws_sdk_1 = require("aws-sdk");
const mockDynamoDb = new aws_sdk_1.DynamoDB.DocumentClient();
describe('getPageViews handler', () => {
    const mockEvent = {
        httpMethod: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    };
    const mockContext = {};
    const mockCallback = jest.fn();
    beforeEach(() => {
        // Reset mock implementation before each test
        mockDynamoDb.query.mockReturnValue({
            promise: jest.fn().mockResolvedValue({ Items: [] })
        });
        mockCallback.mockClear();
    });
    it('should return page views successfully', async () => {
        const mockItems = [{ timestamp: Date.now(), count: 1 }];
        mockDynamoDb.query.mockReturnValue({
            promise: jest.fn().mockResolvedValue({ Items: mockItems })
        });
        const response = await (0, getPageViews_1.handler)(mockEvent, mockContext, mockCallback);
        expect(response.statusCode).toBe(200);
        expect(JSON.parse(response.body)).toEqual(mockItems);
        expect(mockDynamoDb.query).toHaveBeenCalled();
    });
    it('should handle errors gracefully', async () => {
        mockDynamoDb.query.mockReturnValue({
            promise: jest.fn().mockRejectedValue(new Error('DynamoDB error'))
        });
        const response = await (0, getPageViews_1.handler)(mockEvent, mockContext, mockCallback);
        expect(response.statusCode).toBe(500);
        expect(JSON.parse(response.body)).toEqual({
            error: 'Could not fetch page views'
        });
        expect(mockDynamoDb.query).toHaveBeenCalled();
    });
});
