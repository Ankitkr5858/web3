"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const aws_sdk_1 = require("aws-sdk");
const dotenv_1 = __importDefault(require("dotenv"));
const winston_1 = __importDefault(require("winston"));
dotenv_1.default.config();
// Configure logger
const logger = winston_1.default.createLogger({
    level: 'info',
    format: winston_1.default.format.combine(winston_1.default.format.timestamp(), winston_1.default.format.json()),
    transports: [
        new winston_1.default.transports.Console(),
        new winston_1.default.transports.File({ filename: 'error.log', level: 'error' }),
        new winston_1.default.transports.File({ filename: 'combined.log' })
    ]
});
const app = (0, express_1.default)();
const port = process.env.PORT || 3000;
// DynamoDB client configuration
const dynamoDb = new aws_sdk_1.DynamoDB.DocumentClient({
    region: process.env.AWS_REGION || 'us-east-1'
});
// Middleware
app.use((0, cors_1.default)());
app.use(express_1.default.json());
// Record page view endpoint
app.post('/telemetry/pageview', async (_req, res) => {
    const timestamp = Math.floor(Date.now() / 60000) * 60000; // Round to nearest minute
    const params = {
        TableName: process.env.DYNAMODB_TABLE,
        Key: { timestamp },
        UpdateExpression: 'SET #count = if_not_exists(#count, :zero) + :inc',
        ExpressionAttributeNames: {
            '#count': 'count'
        },
        ExpressionAttributeValues: {
            ':inc': 1,
            ':zero': 0
        },
        ReturnValues: 'NONE'
    };
    try {
        await dynamoDb.update(params).promise();
        res.status(200).json({ message: 'Page view recorded successfully' });
    }
    catch (error) {
        logger.error('Error recording page view:', error);
        res.status(500).json({ error: 'Could not record page view' });
    }
});
// Get page views endpoint
app.get('/telemetry/pageviews', async (_req, res) => {
    const now = Date.now();
    const oneHourAgo = now - 3600000;
    const params = {
        TableName: process.env.DYNAMODB_TABLE,
        KeyConditionExpression: '#timestamp >= :oneHourAgo',
        ExpressionAttributeNames: {
            '#timestamp': 'timestamp'
        },
        ExpressionAttributeValues: {
            ':oneHourAgo': oneHourAgo
        }
    };
    try {
        const result = await dynamoDb.query(params).promise();
        res.status(200).json(result.Items);
    }
    catch (error) {
        logger.error('Error fetching page views:', error);
        res.status(500).json({ error: 'Could not fetch page views' });
    }
});
// Health check endpoint
app.get('/health', (_req, res) => {
    res.status(200).json({ status: 'healthy' });
});
app.listen(port, () => {
    logger.info(`Server running on port ${port}`);
});
